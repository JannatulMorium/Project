<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In 2</title>
    <link rel="stylesheet" href="style2.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: sans-serif;
            background: rgb(0, 24, 36);
            background: linear-gradient(210deg, rgba(0, 24, 36, 1) 12%, rgba(26, 125, 145, 1) 36%, rgba(0, 212, 255, 1) 80%);
            height: 100vh;
            width: 100vw;
        }

        .box1 {
            width: 300px;
            padding: 40px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #192a56;
            text-align: center;
        }

        .box1 h1 {
            color: #e84118;
            text-transform: uppercase;
            font-weight: 500;
        }

        .box1 input[type="text"],
        .box1 input[type="password"] {
            border: 0;
            background: none;
            display: block;
            margin: 20px auto;
            text-align: center;
            border: 2px solid #718093;
            padding: 14px 10px;
            width: 200px;
            outline: none;
            color: white;
            border-radius: 24px;
            transition: 0.25s;


        }

        .box1 input[type="text"]:focus,
        .box1 input[type="password"]:focus {
            width: 230px;
            border-color: #e84118;
        }

        .box1 input[type="submit"] {
            border: 0;
            background: none;
            display: block;
            margin: 20px auto;
            text-align: center;
            border: 2px solid #e84118;
            padding: 14px 40px;
            outline: none;
            color: white;
            border-radius: 24px;
            transition: 0.25s;
            cursor: pointer;
        }

        .box1 input[type="submit"]:hover {
            background: #e84118;
        }
    </style>
</head>

<body>
    <form class="box1" action="" method="post">
        <h1>LOG IN</h1>
        <input type="text" name="p_User_Id" placeholder="Username">
        <input type="password" name="p_User_Pass" placeholder="Password">
        <!-- <input type="submit" value="Log IN"> -->
        <!-- <a href="#">Login</a> -->
        <input type="submit" id="submit" name="submit" value="Login">

        <?php

        include 'Connection.php';
        error_reporting(0);
        set_time_limit(1000);

        if (isset($_POST['submit'])) {
            $p_User_Id = $_POST['p_User_Id'];
            $p_User_Pass = $_POST['p_User_Pass'];

            // execute query starts
            // $curs = oci_new_cursor($conn);

            $returnval = 0;
            $stid = oci_parse($conn, "begin DPG_ADMIN_LOGIN.DPD_ADMIN_LOGIN(:o_status,:p_User_Id,:p_User_Pass); end;");


            // oci_bind_by_name($stid, ":cur_data", $curs, -1, OCI_B_CURSOR);
            oci_bind_by_name($stid, ":o_status", $returnval, -1, SQLT_INT);
            oci_bind_by_name($stid, ":p_User_Id", $p_User_Id, -1, SQLT_CHR);
            oci_bind_by_name($stid, ":p_User_Pass", $p_User_Pass, -1, SQLT_CHR);

            oci_execute($stid);
            // oci_execute($curs);
            // execute query ends

            if ($returnval == 1) {
                session_start();
                $_SESSION['USERNAME'] = $p_User_Id;

                header("Location: dashboard.php");
            }
        }



        ?>
    </form>



</body>

</html>